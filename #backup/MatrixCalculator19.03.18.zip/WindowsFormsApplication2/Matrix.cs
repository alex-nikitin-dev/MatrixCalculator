﻿using System;

namespace MatrixCalculator
{
    class Matrix
    {
        #region .ctor

        readonly double[,] _matrix;

        public Matrix(string name, int countRows, int countCols)
        {
            Name = name;
            _matrix = new double[countRows, countCols];
            CountColumns = countCols;
            CountRows = countRows;
            AllItemsCount = countCols * countRows;
        }
        #endregion

        #region .get .set
        public int AllItemsCount { get; }

        public string Name { get; set; }

        public double this[int i, int j]
        {
            get { return _matrix[i, j]; }
            set { _matrix[i, j] = value; }
        }

        public bool IsSevrice { get; set; }
        public int CountRows { get; }

        public int CountColumns { get; }
        public static bool CancelOperation { get; set ; }
       

        #endregion

        #region Algebraic operations
        public static Matrix operator +(Matrix a, Matrix b)
        {
            if (a.CountRows != b.CountRows || a.CountColumns != b.CountColumns)
            {
                throw new ArgumentException($"Сложение матриц невозможно: не совпадают их размеры");
            }

            Matrix result = new Matrix("", a.CountRows, a.CountColumns);


            for (int i = 0; i < a.CountRows; i++)
            {
                for (int j = 0; j < a.CountColumns; j++)
                {
                    result[i, j] = a[i, j] + b[i, j];
                }
            }

            return result;
        }

        public static Matrix operator *(Matrix a, Matrix b)
        {
            if (a.CountColumns != b.CountRows)
            {
                throw new ArgumentException($"Произведение матриц невозможно: они не согласованы");
            }

            Matrix result = new Matrix("", a.CountRows, b.CountColumns);

            for (int i = 0; i < a.CountRows; i++)
            {
                for (int j = 0; j < b.CountColumns; j++)
                {
                    result[i, j] = 0;

                    for (int k = 0; k < a.CountColumns; k++)
                    {
                        result[i, j] += a[i, k] * b[k, j];
                    }
                }
            }

            return result;
        }

        public static Matrix operator -(Matrix a, Matrix b)
        {
            if (a.CountRows != b.CountRows || a.CountColumns != b.CountColumns)
            {
                throw new ArgumentException($"Вычитание матриц невозможно: не совпадают их размеры");
            }
            
            return a + (-1) * b;
        }

        public static Matrix Power(Matrix a, int degree)
        {
            Matrix result = new Matrix("", a.CountRows, a.CountColumns);

            if (degree == 0)
            {
                for (int i = 0; i < a.CountRows; i++)
                {
                    for (int j = 0; j < a.CountColumns; j++)
                    {
                        if (i == j)
                        {
                            result[i, j] = 1;
                        }
                        else
                        {
                            result[i, j] = 0;
                        }
                    }
                }
                return result;
            }

            result = a;

            for (int i = 1; i < degree; i++)
            {
                result *= a;
            }

            return result;
        }
        public static Matrix operator *(double num, Matrix mtrx)
        {
            Matrix result = new Matrix("", mtrx.CountRows, mtrx.CountColumns);
            for (int i = 0; i < mtrx.CountRows; i++)
                for (int j = 0; j < mtrx.CountColumns; j++)
                    result[i, j] = mtrx[i, j] * num;
            return result;
        }

        public static Matrix operator *(Matrix mtrx, double num) // !
        {
            return num * mtrx;
        }

        #endregion

        #region GAUS DEVELOPING
        // ----------------------------DON'T TOUCH----------------------------
        // ----------------------------DON'T TOUCH----------------------------
        // ----------------------------DON'T TOUCH----------------------------
        public Matrix GetClone(string namePostfix)
        {
            var result = new Matrix(Name + namePostfix, CountRows, CountColumns);
            for (int i = 0; i < CountRows; i++)
            {
                for (int j = 0; j < CountColumns; j++)
                {
                    result[i, j] = this[i, j];
                }
            }

            return result;
        }

        public Matrix GetGauss()
        {
            Matrix result = GetClone("_gaussed");
            for (int k = 0; k < CountColumns - 1; k++)
            {
                for (int i = k; i < CountRows - 1; i++)
                {
                    var koef = result[i + 1, k] / result[k, k] * (-1);
                    for (int j = k; j < CountColumns; j++)
                    {
                        result[i + 1, j] += koef * result[k, j];
                    }
                }
            }
            return result;
        }
        public double DeterminantByGauss()
        {
            var gaussed = GetGauss();
            double result = 1;
            for (int i = 0; i < CountRows; i++)
            {
                result *= gaussed[i, i];
            }
            return result;
        }
        public Matrix GetInverseMatrixByGauss()
        {
            if (Determinant() == 0)
                return null;
            var inversedMatrix = (1 / DeterminantByGauss()) * MatrixOfAlgebraicComplements().GetTransposedMatrix();
            inversedMatrix.Name = Name + "_inversed";
            return inversedMatrix;
        }
        public Matrix MatrixOfAlgebraicComplementsByGauss()
        {
            var matrixOfAlgebraicComplements = new Matrix(Name + "_matrixOfAlgebraicComplements", CountRows, CountColumns);
            double sign = 1;
            for (int i = 0; i < CountRows; i++)
                for (int j = 0; j < CountColumns; j++)
                {
                    var temp = GetMatrixOfMinors(i, j);
                    matrixOfAlgebraicComplements[i, j] = temp.DeterminantByGauss() * sign;
                    sign = -sign;
                }
            return matrixOfAlgebraicComplements;
        }

        // ----------------------------DON'T TOUCH END----------------------------
        // ----------------------------DON'T TOUCH END----------------------------
        // ----------------------------DON'T TOUCH END----------------------------
        #endregion

        #region Specific matrix operations

         
        public double Determinant()
        {
            if (CountRows != CountColumns)
            {
                throw new ArgumentException($"Определение детерминанта невозможно: матрица не квадратная");
            }

            if (CancelOperation)
            {
                CancelOperation = false;
                throw new OperationCanceledException("Отмена фоновой операции вычисления детерменанта");
            }

            if (AllItemsCount == 1) return this[0, 0];
            if (AllItemsCount == 4) return this[0, 0] * this[1, 1] - this[0, 1] * this[1, 0];

            double result = 0;
            for (int i = 0; i < CountRows; i++)
            {
                result += ((int)Math.Pow(-1, i)) * this[0, i] * GetMatrixOfMinors(0, i).Determinant();
            }
            return result;
        }

        public Matrix GetMatrixOfMinors(int p, int q)
        {
            var theMatrixOfMinors = new Matrix($"{Name}_minor", CountRows - 1, CountColumns - 1);

            for (int i = 0, newI = 0; i < CountRows; i++)
            {
                for (int j = 0, newJ = 0; j < CountColumns; j++)
                {
                    if (i != p && q != j)
                    {
                        theMatrixOfMinors[newI, newJ++] = this[i, j];
                    }
                }
                if (i != p) newI++;
            }
            return theMatrixOfMinors;
        }

        public Matrix GetTransposedMatrix()
        {
            var transposedMatrix = new Matrix(Name + "_transposed", CountColumns, CountRows);
            for (int i = 0; i < CountRows; i++)
            {
                for (int j = 0; j < CountColumns; j++)
                {
                    transposedMatrix[j, i] = this[i, j];
                }
            }

            return transposedMatrix;
        }


        public Matrix MatrixOfAlgebraicComplements()
        {
            var matrixOfAlgebraicComplements = new Matrix(Name + "_matrixOfAlgebraicComplements", CountRows, CountColumns);
            for (int i = 0; i < CountRows; i++)
                for (int j = 0; j < CountColumns; j++)
                    matrixOfAlgebraicComplements[i, j] = GetMatrixOfMinors(i, j).Determinant() * (int)Math.Pow(-1, i + j);
                
            return matrixOfAlgebraicComplements;
        }

        
        public Matrix GetInverseMatrix()
        {
            if (Determinant() == 0)
            {
                throw new ArgumentException("Невозможно получить обратную матрицу методом алгебраических дополнений, т.к. определитель = 0");
            }
            var inversedMatrix = (1 / Determinant()) * MatrixOfAlgebraicComplements().GetTransposedMatrix();
            inversedMatrix.Name = Name + "_inversed";
            return inversedMatrix;
        }
        #endregion

        #region Acync
        public static void CancelBackground()
        {
            CancelOperation = true;
        }
        #endregion
    }
}
