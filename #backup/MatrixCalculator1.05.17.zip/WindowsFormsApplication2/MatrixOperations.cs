﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace MatrixCalculator
{
    class MatrixOperationis
    {
        public static Dictionary<int, string[]> Priorities { get; }
        public string SrcStr { get; }

        static MatrixOperationis()
        {
            Priorities = new Dictionary<int, string[]>();
            Priorities.Add(0, new[] { "^", });
            Priorities.Add(1, new[] { "*" });
            Priorities.Add(2, new[] { "+", "-" });
        }

        public MatrixOperationis(string sourceStr)
        {
            SrcStr = sourceStr;
        }

        private int _curIndex;
        public enum FindMethod
        {
            IndexOf,
            LastIndexOf
        }

        public static bool IsOperation(string src)
        {
            for (int i = 0; i < Priorities.Keys.Count; i++)
            {
                var priority = Priorities[i];
                foreach (var operation in priority)
                {
                    if (string.Equals(src, operation, StringComparison.Ordinal))
                        return true;
                }
            }
            return false;
        }

        public static int FindAny(string src, int startIndex, FindMethod method)
        {
            for (int i = startIndex;
                method == FindMethod.IndexOf ? i < src.Length : i >= 0;
                i = (method == FindMethod.IndexOf) ? i + 1 : i - 1)
            {
                try
                {
                    if (src[i] == '-'&& src[i - 1] == '(')
                    {
                        if (method == FindMethod.IndexOf)
                        {
                            var iParenthesis = src.IndexOf(")", i - 1, StringComparison.Ordinal);
                            return iParenthesis == -1 ? iParenthesis : iParenthesis + 1;
                        }
                        else
                        {
                            return i - 2;
                        }
                       

                    }
                }
                catch (IndexOutOfRangeException e)
                {
                   Debug.Fail(e.ToString());
                }
              
                if (IsOperation(src[i].ToString()))
                {
                    return i;
                }
                    
            }

            return -1;
            //var oprs = new List<KeyValuePair<string, int>>();
            //for (int i = 0; i < Priorities.Keys.Count; i++)
            //{
            //    var priority = Priorities[i];
            //    foreach (var operation in priority)
            //    {
            //        int index;
            //        if (method == FindMethod.IndexOf)
            //        {
            //            index = src.IndexOf(src, startIndex, StringComparison.Ordinal);
            //        }
            //        else
            //        {
            //            index = src.LastIndexOf(src, startIndex, StringComparison.Ordinal);
            //        }

            //        oprs.Add(new KeyValuePair<string, int>(operation, index));
            //    }
            //}

            //if (oprs.Count == 0)
            //    return -1;

            //KeyValuePair<string, int> extremum = oprs[0];
            //foreach (var pair in oprs)
            //{
            //    if (method == FindMethod.IndexOf)
            //    {
            //        if (method == FindMethod.IndexOf ? pair.Value < extremum.Value : pair.Value > extremum.Value)
            //        {
            //            extremum = pair;
            //        }
            //    }
            //}

            //return extremum.Value;

        }

        public KeyValuePair<string, int>? GetNext()
        {
            for (int i = 0; i < Priorities.Keys.Count; i++)
            {
                var priority = Priorities[i];
                foreach (var operation in priority)
                {
                    var index = SrcStr.IndexOf(operation, _curIndex, StringComparison.Ordinal);
                    if (index != -1)
                    {
                        _curIndex = index+1;
                        return new KeyValuePair<string, int>(operation, index);
                    }
                }
            }

            return null;
        }
    }
}
