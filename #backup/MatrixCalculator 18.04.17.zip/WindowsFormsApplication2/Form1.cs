﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace MatrixCalculator
{
    public partial class MainForm : Form
    {
        #region .ctor

        readonly List<Matrix> _matrixes;
        readonly TableLayoutPanel _tblAllMatrixes;
        readonly Random _random;
        char _name;
        char _serviceName;
        private readonly int _maxCountMatrixes = 5;

        public MainForm()
        {
            InitializeComponent();
            _matrixes = new List<Matrix>();
            _tblAllMatrixes = new TableLayoutPanel();

            grpMain.Controls.Add(_tblAllMatrixes);

            ResetMatrixArray();
            numRowCount.Value = 5;
            numColumnCount.Value = 5;
            _matrixes.Clear();
            _tblAllMatrixes.Controls.Clear();
            _random = new Random();
            ResetServiceName();

        }


        #endregion

        #region matrix collection
        int GetIndexMatrix(string name)
        {
            for (int i = 0; i < _matrixes.Count; i++)
            {
                if (_matrixes[i].Name == name)
                    return i;
            }

            throw new ArgumentOutOfRangeException($"Невозможно найти совпадение имени матрицы");
        }
        char NextName()
        {
            return _name++;
        }
        char NextServiceName()
        {
            return _serviceName++;
        }

        void ResetServiceName()
        {
            _serviceName = 'H';
        }
        void ResetMatrixArray()
        {

            _matrixes.Clear();
            _name = 'A';

            _tblAllMatrixes.Controls.Clear();
            _tblAllMatrixes.ColumnCount = 0;
            _tblAllMatrixes.RowCount = 0;
            _tblAllMatrixes.RowStyles.Clear();
            _tblAllMatrixes.CellBorderStyle = TableLayoutPanelCellBorderStyle.InsetDouble;
            _tblAllMatrixes.Location = new Point(lblCountRow.Right + 20, lblCountRow.Top);
            _tblAllMatrixes.Visible = false;

        }
        void AddMatrix(int countRows, int countCols)
        {
            _matrixes.Add(new Matrix(NextName().ToString(), countRows, countCols));
        }

        Matrix CreateMatrix(int rowsCount, int columnsCount)
        {
            if (_matrixes.Count >= _maxCountMatrixes)
            {
                MessageBox.Show(@"Добавлено максимальное количество матриц", Application.ProductName);
                return null;
            }

            _tblAllMatrixes.AutoSize = false;
            _tblAllMatrixes.RowCount = 3;
            _tblAllMatrixes.ColumnCount++;
            AddMatrix(rowsCount, columnsCount);
            var curMatrix = _matrixes[_matrixes.Count - 1];

            var table = new TableLayoutPanel();
            for (int i = 0; i < rowsCount; i++)
            {
                for (int j = 0; j < columnsCount; j++)
                {
                    var txtItem = new TextBox();
                    txtItem.Size = new Size(25, 20);
                    txtItem.Tag = new MatrixItem(i, j, curMatrix);
                    txtItem.KeyPress += Txt_KeyPress;
                    txtItem.TextChanged += TxtItem_TextChanged;
                    table.Controls.Add(txtItem, j, i);
                }
            }

            _tblAllMatrixes.Controls.Add(table, _tblAllMatrixes.ColumnCount - 1, 0);
            _tblAllMatrixes.RowStyles.Add(new RowStyle());



            var lbl = new TextBox();
            lbl.Text = curMatrix.Name;
            lbl.Tag = curMatrix;
            lbl.ReadOnly = true;
            lbl.Size = new Size(20, lbl.Height);
            lbl.BorderStyle = BorderStyle.None;


            _tblAllMatrixes.Controls.Add(lbl, _tblAllMatrixes.ColumnCount - 1, 1);
            _tblAllMatrixes.RowStyles.Add(new RowStyle());
            _tblAllMatrixes.RowStyles[1].Height = lbl.Height;
            lbl.Anchor = AnchorStyles.None;

            var btnDeterm = new Button();
            btnDeterm.Click += BtnDeterm_Click;
            btnDeterm.Tag = curMatrix;
            btnDeterm.Size = new Size(180, btnDeterm.Height);
            btnDeterm.Text = @"Определитель";
            btnDeterm.Dock = DockStyle.Fill;


            _tblAllMatrixes.Controls.Add(btnDeterm, _tblAllMatrixes.ColumnCount - 1, 2);
            _tblAllMatrixes.RowStyles.Add(new RowStyle());
            _tblAllMatrixes.RowStyles[2].Height = btnDeterm.Height;

            var btnInverse = new Button();
            btnInverse.Click += BtnInverseMatrix_Click;
            btnInverse.Tag = curMatrix;
            btnInverse.Size = new Size(180, btnDeterm.Height);
            btnInverse.Text = @"Обратная";
            btnInverse.Dock = DockStyle.Fill;

            _tblAllMatrixes.Controls.Add(btnInverse, _tblAllMatrixes.ColumnCount - 1, 3);
            _tblAllMatrixes.RowStyles.Add(new RowStyle());
            _tblAllMatrixes.RowStyles[3].Height = btnInverse.Height;


            lbl.AutoSize = true;
            table.AutoSize = true;
            _tblAllMatrixes.AutoSize = true;
            _tblAllMatrixes.Visible = true;

            return curMatrix;
        }
        #endregion

        #region table matrix events


        private void BtnDeterm_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            var curMartrix = (Matrix)btn.Tag;
            try
            {
                ShowPlainText(@"детерменант = " + curMartrix.Determinant());
            }
            catch (ArgumentException exc)
            {
                ShowError(exc.Message);

            }
        }

        private void BtnInverseMatrix_Click(object sender, EventArgs e)
        {

            var btn = (Button)sender;
            var curMartrix = (Matrix)btn.Tag;
            try
            {
                ShowMatrix(curMartrix.GetInverseMatrix());
            }
            catch (ArgumentException exc)
            {
                ShowError(exc.Message);
            }
        }

        #endregion

        #region Events
        private void MainFormLoad(object sender, EventArgs e)
        {

        }
        private void btnFillMatrix_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < _matrixes.Count && i < _maxCountMatrixes; i++)
            {
                FillMatrix(i);
                ShowMatrix(i);
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            if (_matrixes.Count < 2)
            {
                return;
            }

            try
            {
                var sum = _matrixes[0] * _matrixes[1];
                ShowMatrix(sum);
            }
            catch (ArgumentOutOfRangeException err)
            {
                MessageBox.Show(err.Message, Application.ProductName);
            }
        }
        private void btnTestSum_Click(object sender, EventArgs e)
        {
            if (_matrixes.Count < 2)
            {
                return;
            }

            try
            {
                var sum = _matrixes[0] + _matrixes[1];
                ShowMatrix(sum);
            }
            catch (ArgumentOutOfRangeException err)
            {
                MessageBox.Show(err.Message, Application.ProductName);
            }
        }
        private void btnCreateMartix_Click(object sender, EventArgs e)
        {
            CreateMatrix((int)numRowCount.Value, (int)numColumnCount.Value);
        }


        private void TxtItem_TextChanged(object sender, EventArgs e)
        {
            var txt = (TextBox)sender;
            var item = (MatrixItem)txt.Tag;

            double value;
            double.TryParse(txt.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);

            item.Item = value;
        }

        private void Txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar))
                && (e.KeyChar != 45)
                && (e.KeyChar != (char)Keys.Back)
                && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }



        private void rtxtAnswer_TextChanged(object sender, EventArgs e)
        {
            //Console.Beep();
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            //-----------------------------------------------------------------------------
            rtxtAnswer.Clear();
            //-----------------------------------------------------------------------------
            ResetMatrixArray();
        }

        #endregion

        #region Matrix operations

        private void ShowMatrix(Matrix matrix)
        {
            if (matrix == null) return;

            rtxtAnswer.Clear();

            for (int i = 0; i < matrix.CountRows; i++)
            {
                for (int j = 0; j < matrix.CountColumns; j++)
                {
                    rtxtAnswer.AppendText(Math.Round(matrix[i, j], 2).ToString(CultureInfo.InvariantCulture) + "\t");
                }
                rtxtAnswer.AppendText(Environment.NewLine);
            }
        }



        private void FillMatrix(int index)
        {
            if (_matrixes.Count <= index)
            {
                return;
            }



            for (int i = 0; i < _matrixes[index].CountRows; i++)
            {
                for (int j = 0; j < _matrixes[index].CountColumns; j++)
                {
                    _matrixes[index][i, j] = _random.Next(0, 10);
                }
            }
        }

        private void ShowMatrix(int index)
        {
            if (_matrixes.Count <= index)
            {
                return;
            }

            var table = (TableLayoutPanel)_tblAllMatrixes.GetControlFromPosition(index, 0);
            int countRows = _matrixes[index].CountRows;
            int countCols = _matrixes[index].CountColumns;

            for (int i = 0; i < countRows; i++)
            {
                for (int j = 0; j < countCols; j++)
                {
                    var txtItem = (TextBox)table.GetControlFromPosition(j, i);
                    txtItem.TextChanged -= TxtItem_TextChanged;
                    txtItem.Text = Math.Round(_matrixes[index][i, j], 2).ToString(CultureInfo.InvariantCulture);
                    txtItem.TextChanged += TxtItem_TextChanged;
                }
            }

        }


        #endregion

        #region Messages

        void ShowRText(string text, Color clr)
        {
            rtxtAnswer.Text = text;
            rtxtAnswer.SelectAll();
            rtxtAnswer.SelectionColor = clr;
            rtxtAnswer.SelectionLength = 0;
            // rtxtAnswer.ForeColor = old;
        }

        void ShowError(string text)
        {
            ShowRText(text, Color.Red);
        }
        void ShowPlainText(string text)
        {
            ShowRText(text, Color.Black);
        }

        #endregion

        #region parser's engine
        class Objects
        {
            public string LeftObject { get; set; }
            public string LeftSubstring { get; set; }
            public string RightObject { get; set; }
            public string RightSubstring { get; set; }

            public Objects()
            {
                LeftObject = "";
                LeftSubstring = "";
                RightObject = "";
                RightSubstring = "";
            }
        }

        Objects GetObjects(string src, int lIndex, int rIndex)
        {
            var res = new Objects();

            {
                var loperation = MatrixOperationis.FindAny(src, lIndex - 1, MatrixOperationis.FindMethod.LastIndexOf);
                var leftObject = src.Substring(loperation + 1, lIndex - loperation - 1);
                res.LeftObject = leftObject;
                if (MatrixOperationis.IsOperation(res.LeftObject) || res.LeftObject == "")
                {
                    throw new ArgumentException("Ошибка анализа матричного выражения: неверный формат строки.");
                }
                var leftOfleftObject = src.Substring(0, loperation + 1);
                res.LeftSubstring = leftOfleftObject;
            }

            {
                var roperation = MatrixOperationis.FindAny(src, rIndex + 1, MatrixOperationis.FindMethod.IndexOf);
                roperation = roperation == -1 ? src.Length : roperation;
                res.RightObject = src.Substring(rIndex + 1, roperation - rIndex - 1);
                if (MatrixOperationis.IsOperation(res.RightObject) || res.RightObject == "")
                {
                    throw new ArgumentException("Ошибка анализа матричного выражения: неверный формат строки.");
                }
                if (roperation != src.Length) res.RightSubstring = src.Substring(roperation);
            }

            return res;
        }
        private Matrix Parse(string strSource)
        {
            try
            {
                double dAnsw;
                if (double.TryParse(strSource.Trim('(',')'), NumberStyles.Float, CultureInfo.InvariantCulture,out dAnsw))
                {
                    var m = new Matrix("", 1, 1);
                    m[0, 0] = dAnsw;
                    return m;
                }

                if (strSource.Length == 1)
                {
                    var lastMatrixName = strSource[0].ToString();
                    var ind = GetIndexMatrix(lastMatrixName);
                    if (ind > _matrixes.Count - 1)
                    {
                        return null;
                    }
                    return _matrixes[ind];
                }

                var mo = new MatrixOperationis(strSource);
                var nextOperation = mo.GetNext();
                if (nextOperation != null)
                {
                    var nov = nextOperation.Value;
                    var index = nov.Value;
                    var objects = GetObjects(strSource, index, index);
                    var strR = "";

                    double? lDouble = null;
                    double? rDouble = null;
                    try
                    {
                        lDouble = double.Parse(objects.LeftObject.Trim('(', ')'), CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    {
                    }
                    try
                    {
                        rDouble = double.Parse(objects.RightObject.Trim('(', ')'), CultureInfo.InvariantCulture);
                    }
                    catch (Exception)
                    {
                    }
                    int leftIndexMatrix = -1;
                    try
                    {
                        leftIndexMatrix = GetIndexMatrix(objects.LeftObject);
                    }
                    catch (Exception)
                    {
                    }

                    int rightIndexMatrix = -1;
                    try
                    {
                        rightIndexMatrix = GetIndexMatrix(objects.RightObject);
                    }
                    catch (Exception)
                    {
                    }

                    string result = "";
                    if (lDouble != null && rDouble != null)
                    {
                        if (nov.Key == "*")
                            result = (lDouble.Value * rDouble.Value).ToString(CultureInfo.InvariantCulture);
                        if (nov.Key == "+")
                            result = (lDouble.Value + rDouble.Value).ToString(CultureInfo.InvariantCulture);
                        if (nov.Key == "-")
                            result = (lDouble.Value - rDouble.Value).ToString(CultureInfo.InvariantCulture);
                        if (nov.Key == "^")
                            result = (Math.Pow(lDouble.Value, rDouble.Value)).ToString(CultureInfo.InvariantCulture);
                    }
                    else if (lDouble != null && rightIndexMatrix != -1)
                    {
                        if (nov.Key == "*")
                        {
                            Matrix m = (lDouble.Value * _matrixes[rightIndexMatrix]);
                            m.Name = NextServiceName().ToString();
                            _matrixes.Add(m);
                            result = m.Name;
                        }
                    }
                    else if (leftIndexMatrix != -1 && rDouble != null)
                    {
                        if (nov.Key == "*" || nov.Key == "^")
                        {
                            Matrix m = null;
                            if (nov.Key == "*")
                            {
                                m = (_matrixes[leftIndexMatrix] * rDouble.Value);
                            }
                            else if (nov.Key == "^")
                            {
                                if (rDouble == -1)
                                {
                                    m = _matrixes[leftIndexMatrix].GetInverseMatrix();
                                }
                                else if(rDouble >=0)
                                {
                                    m = Matrix.Power(_matrixes[leftIndexMatrix], (int)rDouble.Value);
                                }
                                else if (rDouble < 0)
                                {
                                    throw new ArgumentException("Матрица может быть возведена только в (-1) степень или в степень >0");
                                }
                                
                            }

                            m.Name = NextServiceName().ToString();
                            _matrixes.Add(m);
                            result = m.Name;
                        }
                    }
                    else if (leftIndexMatrix != -1 && rightIndexMatrix != -1)
                    {
                        if (nov.Key == "*" || nov.Key == "+" || nov.Key == "-")
                        {
                            Matrix m = null;
                            if (nov.Key == "*")
                            {
                                m = _matrixes[leftIndexMatrix] * _matrixes[rightIndexMatrix];
                            }
                            else if (nov.Key == "+")
                            {
                                m = _matrixes[leftIndexMatrix] + _matrixes[rightIndexMatrix];
                            }
                            else if (nov.Key == "-")
                            {
                                m = _matrixes[leftIndexMatrix] - _matrixes[rightIndexMatrix];
                            }

                            m.Name = NextServiceName().ToString();
                            _matrixes.Add(m);
                            result = m.Name;
                        }
                    }

                    strR = objects.LeftSubstring + result + objects.RightSubstring;
                    return Parse(strR);
                }

                throw new ArgumentException(@"Невозможно рассчитать выражение: строка имеет неверный формат");
            }
            catch (Exception err)
            {
               
                ////Debug.Fail(err.Message);
                ShowError(err.Message);
               
                //MessageBox.Show(err, Application.ProductName);
                return null;
            }

            //return null;
        }

        void ResetServiceMatrixes()
        {
            for (var i = 0; i < _matrixes.Count; i++)
            {
                var matrix = _matrixes[i];
                if (char.Parse(matrix.Name) >= 'H')
                {
                    _matrixes.Remove(matrix);
                    i--;
                }
            }
        }
        private void btnExprCalc_Click(object sender, EventArgs e)
        {
            string strSource = txtExpr.Text;
            ResetServiceMatrixes();
            ShowPlainText("");
            
            var res = Parse(strSource);
            ResetServiceMatrixes();
            ShowMatrix(res);
        }
#endregion
    }
}

