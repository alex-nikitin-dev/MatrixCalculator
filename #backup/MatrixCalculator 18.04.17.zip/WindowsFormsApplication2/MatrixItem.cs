﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixCalculator
{
    class MatrixItem
    {
         Matrix _ref;
         int _indexI;
         int _indexJ;
        public MatrixItem(int i,int j, Matrix val)
        {
            _indexI = i;
            _indexJ = j;
            _ref = val;
        }
        public double Item
        {
            set
            {
                _ref[_indexI, _indexJ] = value;
            }
            get
            {
                return _ref[_indexI, _indexJ];
            }
        }
    }
}
