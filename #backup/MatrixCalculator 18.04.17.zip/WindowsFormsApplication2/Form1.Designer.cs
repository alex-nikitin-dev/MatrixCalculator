﻿namespace MatrixCalculator
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtAnswer = new System.Windows.Forms.RichTextBox();
            this.btnCreateMartix = new System.Windows.Forms.Button();
            this.grpMain = new System.Windows.Forms.GroupBox();
            this.btnExprCalc = new System.Windows.Forms.Button();
            this.txtExpr = new System.Windows.Forms.TextBox();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnFillMatrix = new System.Windows.Forms.Button();
            this.btnTestSum = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCountRow = new System.Windows.Forms.Label();
            this.numColumnCount = new System.Windows.Forms.NumericUpDown();
            this.numRowCount = new System.Windows.Forms.NumericUpDown();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.grpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numColumnCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRowCount)).BeginInit();
            this.SuspendLayout();
            // 
            // rtxtAnswer
            // 
            this.rtxtAnswer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtxtAnswer.Location = new System.Drawing.Point(12, 451);
            this.rtxtAnswer.Name = "rtxtAnswer";
            this.rtxtAnswer.Size = new System.Drawing.Size(1176, 242);
            this.rtxtAnswer.TabIndex = 0;
            this.rtxtAnswer.Text = "";
            this.rtxtAnswer.TextChanged += new System.EventHandler(this.rtxtAnswer_TextChanged);
            // 
            // btnCreateMartix
            // 
            this.btnCreateMartix.Location = new System.Drawing.Point(17, 107);
            this.btnCreateMartix.Name = "btnCreateMartix";
            this.btnCreateMartix.Size = new System.Drawing.Size(90, 23);
            this.btnCreateMartix.TabIndex = 2;
            this.btnCreateMartix.Text = "добавить";
            this.btnCreateMartix.UseVisualStyleBackColor = true;
            this.btnCreateMartix.Click += new System.EventHandler(this.btnCreateMartix_Click);
            // 
            // grpMain
            // 
            this.grpMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpMain.Controls.Add(this.label1);
            this.grpMain.Controls.Add(this.btnExprCalc);
            this.grpMain.Controls.Add(this.txtExpr);
            this.grpMain.Controls.Add(this.btnMultiply);
            this.grpMain.Controls.Add(this.btnFillMatrix);
            this.grpMain.Controls.Add(this.btnTestSum);
            this.grpMain.Controls.Add(this.btnClearAll);
            this.grpMain.Controls.Add(this.label2);
            this.grpMain.Controls.Add(this.lblCountRow);
            this.grpMain.Controls.Add(this.numColumnCount);
            this.grpMain.Controls.Add(this.numRowCount);
            this.grpMain.Controls.Add(this.btnCreateMartix);
            this.grpMain.Location = new System.Drawing.Point(12, 21);
            this.grpMain.Name = "grpMain";
            this.grpMain.Size = new System.Drawing.Size(1176, 407);
            this.grpMain.TabIndex = 5;
            this.grpMain.TabStop = false;
            this.grpMain.Text = "Введите размерность матрицы";
            // 
            // btnExprCalc
            // 
            this.btnExprCalc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnExprCalc.Location = new System.Drawing.Point(322, 378);
            this.btnExprCalc.Name = "btnExprCalc";
            this.btnExprCalc.Size = new System.Drawing.Size(157, 23);
            this.btnExprCalc.TabIndex = 14;
            this.btnExprCalc.Text = "Расчитать выражение";
            this.btnExprCalc.UseVisualStyleBackColor = true;
            this.btnExprCalc.Click += new System.EventHandler(this.btnExprCalc_Click);
            // 
            // txtExpr
            // 
            this.txtExpr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtExpr.Location = new System.Drawing.Point(6, 381);
            this.txtExpr.Name = "txtExpr";
            this.txtExpr.Size = new System.Drawing.Size(310, 20);
            this.txtExpr.TabIndex = 13;
            // 
            // btnMultiply
            // 
            this.btnMultiply.Location = new System.Drawing.Point(17, 276);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(172, 23);
            this.btnMultiply.TabIndex = 12;
            this.btnMultiply.Text = "умножить 2 первые матрицы";
            this.btnMultiply.UseVisualStyleBackColor = true;
            this.btnMultiply.Visible = false;
            this.btnMultiply.Click += new System.EventHandler(this.btnMultiply_Click);
            // 
            // btnFillMatrix
            // 
            this.btnFillMatrix.Location = new System.Drawing.Point(17, 189);
            this.btnFillMatrix.Name = "btnFillMatrix";
            this.btnFillMatrix.Size = new System.Drawing.Size(172, 23);
            this.btnFillMatrix.TabIndex = 11;
            this.btnFillMatrix.Text = "заполнить все матрицы";
            this.btnFillMatrix.UseVisualStyleBackColor = true;
            this.btnFillMatrix.Click += new System.EventHandler(this.btnFillMatrix_Click);
            // 
            // btnTestSum
            // 
            this.btnTestSum.Location = new System.Drawing.Point(17, 234);
            this.btnTestSum.Name = "btnTestSum";
            this.btnTestSum.Size = new System.Drawing.Size(172, 23);
            this.btnTestSum.TabIndex = 10;
            this.btnTestSum.Text = "сложить две первые матрицы";
            this.btnTestSum.UseVisualStyleBackColor = true;
            this.btnTestSum.Visible = false;
            this.btnTestSum.Click += new System.EventHandler(this.btnTestSum_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(17, 151);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(90, 23);
            this.btnClearAll.TabIndex = 9;
            this.btnClearAll.Text = "очистить";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "кол-во столбцов";
            // 
            // lblCountRow
            // 
            this.lblCountRow.AutoSize = true;
            this.lblCountRow.Location = new System.Drawing.Point(118, 35);
            this.lblCountRow.Name = "lblCountRow";
            this.lblCountRow.Size = new System.Drawing.Size(72, 13);
            this.lblCountRow.TabIndex = 6;
            this.lblCountRow.Text = "кол-во строк";
            // 
            // numColumnCount
            // 
            this.numColumnCount.Location = new System.Drawing.Point(17, 70);
            this.numColumnCount.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numColumnCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numColumnCount.Name = "numColumnCount";
            this.numColumnCount.Size = new System.Drawing.Size(90, 20);
            this.numColumnCount.TabIndex = 4;
            this.numColumnCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numRowCount
            // 
            this.numRowCount.Location = new System.Drawing.Point(17, 31);
            this.numRowCount.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numRowCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numRowCount.Name = "numRowCount";
            this.numRowCount.Size = new System.Drawing.Size(90, 20);
            this.numRowCount.TabIndex = 3;
            this.numRowCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 696);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1200, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(6, 363);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "Пример: A^(-1)*2+A*B^2+C*(-100)";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 718);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpMain);
            this.Controls.Add(this.rtxtAnswer);
            this.Name = "MainForm";
            this.Text = "Калькулятор матриц";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.grpMain.ResumeLayout(false);
            this.grpMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numColumnCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRowCount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtAnswer;
        private System.Windows.Forms.Button btnCreateMartix;
        private System.Windows.Forms.GroupBox grpMain;
        private System.Windows.Forms.NumericUpDown numColumnCount;
        private System.Windows.Forms.NumericUpDown numRowCount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCountRow;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button btnTestSum;
        private System.Windows.Forms.Button btnFillMatrix;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.Button btnExprCalc;
        private System.Windows.Forms.TextBox txtExpr;
        private System.Windows.Forms.Label label1;
    }
}

